#!/bin/sh

./brTest
